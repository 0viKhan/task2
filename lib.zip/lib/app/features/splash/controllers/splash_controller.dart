import 'package:flutter/animation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../routes/app_routes.dart';

class SplashController extends GetxController with GetSingleTickerProviderStateMixin {
  late AnimationController animationController;
  late Animation<double> fadeAnimation;
  late Animation<double> slideAnimation;

  @override
  void onInit() {
    super.onInit();

    animationController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    fadeAnimation = CurvedAnimation(
      parent: animationController,
      curve: const Interval(0.0, 0.7, curve: Curves.easeOut),
    );

    slideAnimation = Tween<double>(begin: 30, end: 0).animate(
      CurvedAnimation(
        parent: animationController,
        curve: const Interval(0.0, 0.7, curve: Curves.easeOut),
      ),
    );

    animationController.forward();
    _navigateNext();
  }

  void _navigateNext() async {
    debugPrint("Splash: navigating to onboarding in 3s...");
    await Future.delayed(const Duration(seconds: 3));
    debugPrint("Splash: navigating now -> ${AppRoutes.onboarding}");
    Get.offAllNamed(AppRoutes.onboarding);
  }

  @override
  void onClose() {
    animationController.dispose();
    super.onClose();
  }
}