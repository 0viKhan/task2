class ProductModel {
  final String name;
  final double price;
  final int stock;

  final String? description;
  final String? category;
  final String? brand;
  final bool? isDiscounted;
  final double? discountPercent;
  final bool? isActive;
  final double? weight;
  final List<String>? colors;
  final List<String>? tags;
  final String? dimensions;

  ProductModel({
    required this.name,
    required this.price,
    required this.stock,
    this.description,
    this.category,
    this.brand,
    this.isDiscounted,
    this.discountPercent,
    this.isActive,
    this.weight,
    this.colors,
    this.tags,
    this.dimensions,
  });

  Map<String, dynamic> toJson() {
    return {
      "name": name,
      "price": price,
      "stock": stock,
      if (description != null) "description": description,
      if (category != null) "category": category,
      if (brand != null) "brand": brand,
      if (isDiscounted != null) "isDiscounted": isDiscounted,
      if (discountPercent != null) "discountPercent": discountPercent,
      if (isActive != null) "isActive": isActive,
      if (weight != null) "weight": weight,
      if (colors != null) "colors": colors,
      if (tags != null) "tags": tags,
      if (dimensions != null) "dimensions": dimensions,
    };
  }
}