import 'dart:io';

import 'package:dio/dio.dart' as dio;
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../model/product_model.dart';
import '../../../../services/product_service.dart';

class ProductController extends GetxController {
  final ProductService _service = ProductService();

  // ----------------------------
  // State
  // ----------------------------
  final RxBool isLoading = false.obs;
  final RxBool isCreating = false.obs;

  final RxString errorMessage = ''.obs;

  /// Products list (response parsing unknown বলে Map রেখেছি safe করে)
  final RxList<dynamic> products = <dynamic>[].obs;

  /// Picked image for create product
  final Rx<File?> selectedImage = Rx<File?>(null);

  // ----------------------------
  // Lifecycle
  // ----------------------------
  @override
  void onInit() {
    super.onInit();
    fetchProducts();
  }

  // ----------------------------
  // Image picker
  // ----------------------------
  Future<void> pickImage({ImageSource source = ImageSource.gallery}) async {
    final picked = await ImagePicker().pickImage(source: source);
    if (picked != null) {
      selectedImage.value = File(picked.path);
    }
  }

  void clearPickedImage() {
    selectedImage.value = null;
  }

  // ----------------------------
  // GET: Products
  // ----------------------------
  Future<void> fetchProducts() async {
    try {
      isLoading.value = true;
      errorMessage.value = '';

      final dio.Response res = await _service.getProducts();

      // backend response structure different হতে পারে, তাই safe parse:
      if (res.statusCode == 200 && (res.data?["success"] == true || res.data?["statusCode"] == 200)) {
        final data = res.data;

        // Common patterns: data["data"], data["data"]["result"], data["data"]["items"]
        dynamic list =
            data?["data"]?["result"] ??
                data?["data"]?["items"] ??
                data?["data"] ??
                data?["result"] ??
                data?["items"];

        if (list is List) {
          products.assignAll(list);
        } else {
          products.clear();
        }
      } else {
        errorMessage.value = res.data?["message"]?.toString() ?? "Failed to load products";
      }
    } on dio.DioException catch (e) {
      errorMessage.value = _dioErrorMessage(e, fallback: "Failed to load products");
    } catch (_) {
      errorMessage.value = "Something went wrong";
    } finally {
      isLoading.value = false;
    }
  }

  // ----------------------------
  // POST: Create Product
  // ----------------------------
  Future<void> createProduct({
    required String name,
    required double price,
    required int stock,
    String? description,
    String? category,
    String? brand,
    bool? isDiscounted,
    double? discountPercent,
    bool? isActive,
    double? weight,
    List<String>? colors,
    List<String>? tags,
    String? dimensions,
  }) async {
    try {
      isCreating.value = true;
      errorMessage.value = '';

      final product = ProductModel(
        name: name,
        price: price,
        stock: stock,
        description: description,
        category: category,
        brand: brand,
        isDiscounted: isDiscounted,
        discountPercent: discountPercent,
        isActive: isActive,
        weight: weight,
        colors: colors,
        tags: tags,
        dimensions: dimensions,
      );

      final dio.Response res = await _service.createProduct(
        product: product,
        imageFile: selectedImage.value,
      );

      if (res.statusCode == 200 || res.statusCode == 201) {
        if (res.data?["success"] == true) {
          Get.snackbar("Success", res.data?["message"]?.toString() ?? "Product created");
          clearPickedImage();
          await fetchProducts();
          return;
        }
      }

      Get.snackbar("Error", res.data?["message"]?.toString() ?? "Create product failed");
    } on dio.DioException catch (e) {
      final msg = _dioErrorMessage(e, fallback: "Create product failed");
      Get.snackbar("Error", msg);
    } catch (_) {
      Get.snackbar("Error", "Something went wrong");
    } finally {
      isCreating.value = false;
    }
  }

  // ----------------------------
  // Helpers
  // ----------------------------
  String _dioErrorMessage(dio.DioException e, {required String fallback}) {
    try {
      final data = e.response?.data;

      if (data is Map && data["message"] != null) {
        return data["message"].toString();
      }

      if (data is String && data.isNotEmpty) {
        return data;
      }

      return fallback;
    } catch (_) {
      return fallback;
    }
  }
}