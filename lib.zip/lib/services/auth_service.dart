import 'package:dio/dio.dart' as dio;
import 'package:get/get.dart';
import '../app/core/constants/api_constants.dart';
import '../app/core/network/dio_client.dart';
import '../app/core/storage/pref_service.dart';

class AuthService extends GetxService {
  final dio.Dio _dio = DioClient().dio;

  Future<dio.Response> register({
    required String fullName,
    required String email,
    required String password,
  }) async {
    return await _dio.post(
      ApiConstants.register,
      data: {
        "fullName": fullName,
        "email": email,
        "password": password,
      },
    );
  }

  Future<dio.Response> login({
    required String email,
    required String password,
  }) async {
    final response = await _dio.post(
      ApiConstants.login,
      data: {
        "email": email,
        "password": password,
      },
    );

    final token = response.data["token"];
    if (token != null) {
      await PrefService.setString("token", token);
    }

    return response;
  }

  Future<void> logout() async {
    await PrefService.remove("token");
  }
}
Future<dio.Response> forgotPassword(String email) async {
  return await _dio.post(
    "/api/v1/auth/forgot-password",
    data: {"email": email},
  );
}

Future<dio.Response> verifyOtp({
  required String email,
  required int otp,
}) async {
  return await _dio.post(
    "/api/v1/auth/verify-otp",
    data: {
      "email": email,
      "otp": otp,
    },
  );
}

Future<dio.Response> resetPassword({
  required String email,
  required String password,
  required String token,
}) async {
  return await _dio.post(
    "/api/v1/auth/reset-password",
    options: dio.Options(
      headers: {"Authorization": "Bearer $token"},
    ),
    data: {
      "email": email,
      "password": password,
    },
  );
}